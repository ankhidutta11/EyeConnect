/* ============================================================
   QUICK PHRASES AND SHARED EDITOR
   ============================================================ */
const categories=[
  ["needs","Basic needs","बुनियादी ज़रूरतें"],["health","Health","स्वास्थ्य"],
  ["family","Family","परिवार"],["feelings","Feelings","भावनाएँ"],
  ["questions","Questions","प्रश्न"],["greetings","Greetings","अभिवादन"]
];
const builtPhrases={
  needs:[["I need water.","मुझे पानी चाहिए।"],["I need food.","मुझे खाना चाहिए।"],["I need the bathroom.","मुझे शौचालय जाना है।"]],
  health:[["I am in pain.","मुझे दर्द हो रहा है।"],["Please change my position.","कृपया मेरी स्थिति बदलें।"],["I need my medicine.","मुझे मेरी दवा चाहिए।"]],
  family:[["Please call my family.","कृपया मेरे परिवार को बुलाएँ।"],["I love you.","मैं आपसे प्यार करता हूँ।"]],
  feelings:[["I am comfortable.","मैं आराम में हूँ।"],["I feel cold.","मुझे ठंड लग रही है।"],["I am happy.","मैं खुश हूँ।"]],
  questions:[["What time is it?","कितने बजे हैं?"],["Can you help me?","क्या आप मेरी मदद कर सकते हैं?"]],
  greetings:[["Hello!","नमस्ते!"],["Thank you.","धन्यवाद।"],["Good morning.","सुप्रभात।"]]
};
let editCallback=null,confirmCallback=null;
function openEditor(title,value,callback){
  $("#editTitle").textContent=title;$("#editLabel").textContent=tr("Text","टेक्स्ट");
  $("#editText").value=value;editCallback=callback;
  $("#editDialog").showModal();$("#editText").focus();
}
$("#editSave").onclick=()=>{
  const text=$("#editText").value.trim();
  if(!text){toast(tr("Please enter some text.","कृपया टेक्स्ट डालें।"));return}
  $("#editDialog").close();editCallback?.(text);
};
function confirmAction(title,callback){
  $("#confirmTitle").textContent=title;confirmCallback=callback;$("#confirmDialog").showModal();
}
$("#confirmYes").onclick=()=>{$("#confirmDialog").close();confirmCallback?.()};
function renderQuick(){
  const select=$("#phraseCategory"),old=select.value||"needs";
  select.innerHTML=categories.map(([id,en,hi])=>`<option value="${id}">${esc(tr(en,hi))}</option>`).join("");
  select.value=old;
  const cat=select.value,lang=state.settings.lang;
  const items=[
    ...builtPhrases[cat].map(([en,hi],i)=>({id:`builtin-${cat}-${i}`,text:tr(en,hi),builtin:true})),
    ...state.phrases.filter(x=>x.category===cat&&x.lang===lang)
  ];
  $("#quickList").innerHTML=items.map(x=>`<div class="phrase-item">
    <button class="say" data-dwell data-phrase="${esc(x.id)}">${esc(x.text)}</button>
    <button class="mini" data-dwell data-edit-phrase="${esc(x.id)}">${T(x.builtin?"Customize":"Edit",x.builtin?"अपना संस्करण":"संपादित करें")}</button>
    ${x.builtin?"":`<button class="mini" data-dwell data-del-phrase="${esc(x.id)}">${T("Delete","मिटाएँ")}</button>`}
  </div>`).join("");
}
function phraseById(id){
  if(id.startsWith("builtin-")){
    const [,cat,i]=id.split("-");
    const p=builtPhrases[cat]?.[Number(i)];
    return p?{text:tr(...p),category:cat,builtin:true}:null;
  }
  return state.phrases.find(x=>x.id===id);
}
$("#phraseCategory").onchange=renderQuick;
$("#addPhrase").onclick=()=>openEditor(tr("Add a quick phrase","तुरंत बोलने का वाक्य जोड़ें"),"",text=>{
  state.phrases.push({id:uid(),text,category:$("#phraseCategory").value,lang:state.settings.lang});
  save();renderQuick();
});
$("#quickList").onclick=e=>{
  const say=e.target.closest("[data-phrase]");
  if(say){const p=phraseById(say.dataset.phrase);if(p){speak(p.text,"quick");emit("quick")}}
  const edit=e.target.closest("[data-edit-phrase]");
  if(edit){
    const id=edit.dataset.editPhrase,p=phraseById(id);
    if(p)openEditor(tr("Edit phrase","वाक्य संपादित करें"),p.text,text=>{
      if(p.builtin)state.phrases.push({id:uid(),text,category:p.category,lang:state.settings.lang});
      else p.text=text;
      save();renderQuick();
    });
  }
  const del=e.target.closest("[data-del-phrase]");
  if(del){state.phrases=state.phrases.filter(x=>x.id!==del.dataset.delPhrase);save();renderQuick()}
};

/* ============================================================
   MOCK AUTH
   ============================================================ */
let authMode="login",authOffered=!!state.session;
function openAuth(mode="login"){
  authOffered=true;authMode=mode;
  $("#authTitle").textContent=mode==="signup"?tr("Create your demo account","अपना डेमो खाता बनाएँ"):tr("Welcome back","फिर से स्वागत है");
  $("#nameGroup").hidden=$("#confirmGroup").hidden=mode!=="signup";
  $("#authSubmit").textContent=mode==="signup"?tr("Create account","खाता बनाएँ"):tr("Login","लॉगिन");
  $("#authSwitch").textContent=mode==="signup"?tr("Already have an account? Login","खाता है? लॉगिन करें"):tr("New here? Sign up","नए हैं? खाता बनाएँ");
  $("#authError").textContent="";
  if(!$("#authDialog").open)$("#authDialog").showModal();
}
$("#loginButton").onclick=()=>openAuth("login");
$("#signupButton").onclick=()=>openAuth("signup");
$("#authSwitch").onclick=()=>openAuth(authMode==="login"?"signup":"login");
$("#authForm").onsubmit=e=>{
  e.preventDefault();
  const name=$("#authName").value.trim(),email=$("#authEmail").value.trim().toLowerCase();
  const password=$("#authPassword").value,confirm=$("#authConfirm").value;
  let error="";
  if(!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email))error=tr("Please enter a valid email address.","सही ईमेल पता डालें।");
  else if(password.length<6)error=tr("Use at least 6 characters for your demo password.","डेमो पासवर्ड में कम से कम 6 अक्षर रखें।");
  else if(authMode==="signup"){
    if(!name)error=tr("Please enter your name.","अपना नाम डालें।");
    else if(password!==confirm)error=tr("The passwords do not match.","पासवर्ड मेल नहीं खाते।");
    else if(state.accounts.some(x=>x.email===email))error=tr("That email already has a demo account. Please log in.","इस ईमेल का डेमो खाता है। लॉगिन करें।");
    else{
      const account={id:uid(),name,email,password};
      state.accounts.push(account);state.session={id:account.id,name,email};
    }
  }else{
    const account=state.accounts.find(x=>x.email===email&&x.password===password);
    if(!account)error=tr("Email or demo password is incorrect.","ईमेल या डेमो पासवर्ड गलत है।");
    else state.session={id:account.id,name:account.name,email:account.email};
  }
  if(error){$("#authError").textContent=error;return}
  save();$("#authPassword").value=$("#authConfirm").value="";
  $("#authDialog").close();updateSession();go("dashboard");
};
$("#guestButton").onclick=()=>{
  state.session={id:"guest",name:tr("Guest","अतिथि"),email:""};
  save();$("#authDialog").close();updateSession();go("dashboard");
};
function updateSession(){
  const user=state.session;
  $("#sessionBadge").textContent=user?tr("Hello, ","नमस्ते, ")+user.name:tr("Guest-ready · no account required","अतिथि मोड · खाते की ज़रूरत नहीं");
  $("#accountName").value=user?.name||"";
  $("#accountEmail").value=user?.email||tr("Guest / not signed in","अतिथि / लॉगिन नहीं");
}
$("#accountName").oninput=e=>{
  if(!state.session)state.session={id:"guest",name:"",email:""};
  state.session.name=e.target.value;
  const account=state.accounts.find(x=>x.id===state.session.id);
  if(account)account.name=e.target.value;
  save();$("#sessionBadge").textContent=tr("Hello, ","नमस्ते, ")+e.target.value;
};
$("#logoutButton").onclick=()=>{
  state.session=null;save();updateSession();toast(tr("Logged out. Guest controls remain available.","लॉगआउट हो गया। अतिथि नियंत्रण उपलब्ध हैं।"));
};
$$("[data-close]").forEach(b=>b.onclick=()=>b.closest("dialog").close());
["authDialog","editDialog"].forEach(id=>{
  $("#"+id).addEventListener("close",()=>{
    $("#keyboardHome").append($("#keyboardDock"));activeInput=mainTarget;
    $("#authKeyboard").hidden=true;renderSuggestions();
  });
});
$("#deleteData").onclick=()=>confirmAction(tr("Delete all EyeConnect data in this browser?","इस ब्राउज़र का पूरा EyeConnect डेटा मिटाएँ?"),()=>{
  stopTracking();
  try{localStorage.removeItem(KEY)}catch{}
  location.reload();
});
