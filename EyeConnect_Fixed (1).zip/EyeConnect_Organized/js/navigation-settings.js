/* ============================================================
   SETTINGS: ALL RANGES AND SELECTS GET GAZE-FRIENDLY +/- CONTROLS
   ============================================================ */
function rangeSetting(key,en,hi,min,max,step){
  return `<div class="setting">
    <label for="set-${key}">${T(en,hi)}: <output id="out-${key}"></output></label>
    <input type="range" id="set-${key}" data-setting="${key}"
      min="${min}" max="${max}" step="${step}" value="${state.settings[key]}">
  </div>`;
}
function selectSetting(key,en,hi,options){
  return `<div class="setting"><label for="set-${key}">${T(en,hi)}</label>
    <select id="set-${key}" data-setting="${key}" data-dwell>
      ${options.map(([v,a,b])=>`<option value="${v}" ${String(state.settings[key])===v?"selected":""}>${esc(tr(a,b))}</option>`).join("")}
    </select></div>`;
}
function toggleSetting(key,en,hi){
  return `<div class="setting"><button data-dwell data-toggle="${key}" aria-pressed="${!!state.settings[key]}">${T(en,hi)} <strong id="toggle-${key}"></strong></button></div>`;
}
function buildSettings(){
  $("#accessSettings").innerHTML=
    rangeSetting("dwell","Dwell time (seconds)","नज़र टिकाने का समय (सेकंड)",.5,5,.1)+
    selectSetting("lang","Language","भाषा",[["en","English","English"],["hi","हिन्दी","हिन्दी"]])+
    selectSetting("keySize","Keyboard size","कीबोर्ड आकार",[
      ["small","Small","छोटा"],["medium","Medium","मध्यम"],["large","Large","बड़ा"],["xl","Extra large","बहुत बड़ा"]
    ])+
    rangeSetting("font","Text size","टेक्स्ट आकार",.9,1.5,.05)+
    selectSetting("theme","Theme","थीम",[["dark","Dark","डार्क"],["light","Light","लाइट"]])+
    toggleSetting("contrast","High contrast","उच्च कंट्रास्ट")+
    toggleSetting("arrows","Floating scroll arrows","स्क्रॉल तीर");
  $("#eyeSettings").innerHTML=
    rangeSetting("gain","Gaze sensitivity","नज़र संवेदनशीलता",.5,2,.05)+
    rangeSetting("smooth","Smoothing","स्मूदिंग",0,.95,.05)+
    toggleSetting("blink","Blink filter","पलक फ़िल्टर");
  $("#voiceSettings").innerHTML=
    rangeSetting("rate","Speed","गति",.5,2,.1)+
    rangeSetting("pitch","Pitch","सुर",0,2,.1)+
    rangeSetting("volume","Volume","वॉल्यूम",0,1,.05)+
    toggleSetting("autoSpeak","Auto-speak completed sentences","पूरा वाक्य अपने आप बोलें");
  $$("[data-setting]").forEach(el=>{
    el.addEventListener("input",()=>{
      const key=el.dataset.setting;
      state.settings[key]=el.type==="range"?Number(el.value):el.value;
      if(key==="lang"){
        state.settings.voice="";symbols=false;
        buildSettings();applyLanguage();renderCameraList();
      }
      applySettings();save();
    });
  });
  $$("[data-toggle]").forEach(el=>el.onclick=()=>{
    const key=el.dataset.toggle;state.settings[key]=!state.settings[key];
    applySettings();save();
  });
  enhanceControls(document);
  applySettings();
}
function applySettings(){
  const s=state.settings;
  document.body.classList.toggle("light",s.theme==="light");
  document.body.classList.toggle("contrast",s.contrast);
  document.documentElement.style.setProperty("--text",s.font);
  document.documentElement.style.setProperty("--key",({small:64,medium:72,large:86,xl:100}[s.keySize]||72)+"px");
  $("#arrows").hidden=!s.arrows;
  $$("[data-setting]").forEach(el=>{
    const out=$("#out-"+el.dataset.setting);
    if(out)out.textContent=Number(s[el.dataset.setting]).toFixed(2);
  });
  $$("[data-toggle]").forEach(el=>{
    const on=!!s[el.dataset.toggle];
    el.setAttribute("aria-pressed",String(on));
    $("#toggle-"+el.dataset.toggle).textContent=tr(on?"On":"Off",on?"चालू":"बंद");
  });
}
function enhanceControls(root){
  $$('input[type="range"],select',root).forEach(el=>{
    if(el.dataset.enhanced)return;
    el.dataset.enhanced="true";
    const tools=document.createElement("div");tools.className="input-tools";
    const label=()=>document.querySelector(`label[for="${el.id}"]`)?.textContent||el.id;
    [-1,1].forEach(dir=>{
      const b=document.createElement("button");
      b.type="button";b.dataset.dwell="";
      b.textContent=dir<0?"−":"+";
      b.setAttribute("aria-label",(dir<0?"Decrease / previous: ":"Increase / next: ")+label());
      b.onclick=()=>{
        if(el.tagName==="SELECT"){
          el.selectedIndex=clamp(el.selectedIndex+dir,0,el.options.length-1);
        }else{
          el.value=clamp(Number(el.value)+dir*Number(el.step||1),Number(el.min),Number(el.max));
        }
        el.dispatchEvent(new Event("input",{bubbles:true}));
        el.dispatchEvent(new Event("change",{bubbles:true}));
      };
      tools.append(b);
    });
    el.after(tools);
  });
}
