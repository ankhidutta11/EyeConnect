/* ============================================================
   SPEECH AND HISTORY
   ============================================================ */
let voices=[];
const speechAvailable="speechSynthesis" in window;
function renderVoices(){
  voices=speechAvailable?speechSynthesis.getVoices():[];
  const lang=state.settings.lang;
  const matching=voices.filter(v=>v.lang.toLowerCase().startsWith(lang));
  const others=voices.filter(v=>!matching.includes(v));
  $("#voiceSelect").innerHTML=
    `<option value="">${esc(tr("Automatic language voice","भाषा के अनुसार आवाज़"))}</option>`+
    [...matching,...others].map(v=>`<option value="${esc(v.voiceURI)}">${esc(v.name+" · "+v.lang)}</option>`).join("");
  $("#voiceSelect").value=state.settings.voice;
  $("#voiceNotice").textContent=!speechAvailable
    ?tr("Speech is unavailable in this browser. Text and copying still work.","इस ब्राउज़र में आवाज़ उपलब्ध नहीं है। टेक्स्ट और कॉपी काम करेंगे।")
    :lang==="hi"&&!matching.length
      ?tr("No Hindi voice is installed. Install a Hindi system voice, then reload. Speech will try the system default.","हिन्दी आवाज़ इंस्टॉल नहीं है। सिस्टम में हिन्दी आवाज़ जोड़कर दोबारा खोलें। अभी सिस्टम की डिफ़ॉल्ट आवाज़ आज़माई जाएगी।")
      :tr("Some system voices may use an online speech service. Choose a local voice for sensitive text.","कुछ सिस्टम आवाज़ें ऑनलाइन सेवा इस्तेमाल कर सकती हैं। संवेदनशील टेक्स्ट के लिए स्थानीय आवाज़ चुनें।");
}
$("#voiceSelect").onchange=e=>{state.settings.voice=e.target.value;save()};
if(speechAvailable)speechSynthesis.addEventListener("voiceschanged",renderVoices);
function speak(text,type="normal",options={}){
  text=String(text).trim();if(!text)return;
  const lang=options.lang||state.settings.lang;
  if(options.record!==false){
    addHistory(text,type,lang);
    learnText(text);
  }
  if(!speechAvailable){toast(tr("Speech is unavailable; your message is still saved.","आवाज़ उपलब्ध नहीं है; संदेश सहेजा गया है।"));return}
  try{
    speechSynthesis.cancel();
    const u=new SpeechSynthesisUtterance(text);
    const chosen=voices.find(v=>v.voiceURI===state.settings.voice)||
      voices.find(v=>v.lang.toLowerCase().startsWith(lang));
    if(chosen)u.voice=chosen;
    u.lang=lang==="hi"?"hi-IN":"en-IN";
    u.rate=state.settings.rate;u.pitch=state.settings.pitch;u.volume=state.settings.volume;
    u.onerror=e=>{
      if(!["interrupted","canceled"].includes(e.error))
        toast(tr("Speech could not play. Try a different voice or click Test voice.","आवाज़ नहीं चल सकी। दूसरी आवाज़ चुनें या आवाज़ जाँचें पर क्लिक करें।"));
    };
    speechSynthesis.speak(u);
  }catch{toast(tr("Your browser blocked speech. Click Test voice once.","ब्राउज़र ने आवाज़ रोकी। एक बार आवाज़ जाँचें पर क्लिक करें।"))}
}
$("#speakButton").onclick=()=>{speak(mainTarget.value);emit("speak")};
$("#testVoice").onclick=()=>speak(tr("Hello. This is my voice.","नमस्ते। यह मेरी आवाज़ है।"),"normal",{record:false});
let typedTimer;
mainTarget.addEventListener("input",()=>{
  clearTimeout(typedTimer);
  typedTimer=setTimeout(()=>{
    const text=mainTarget.value.trim();
    if(text&&state.history[0]?.text!==text)addHistory(text,"normal",state.settings.lang,true);
  },2500);
});
function addHistory(text,type,lang,typed=false){
  state.history.unshift({id:uid(),text,type,lang,typed,time:Date.now()});
  state.history=state.history.slice(0,500);
  save();renderHistory();
}
function renderHistory(){
  const term=$("#historySearch").value.toLocaleLowerCase();
  const filter=$("#historyFilter").value||"all";
  const list=state.history.filter(x=>(filter==="all"||x.type===filter)&&x.text.toLocaleLowerCase().includes(term));
  $("#historyList").innerHTML=list.length?list.map(x=>
    `<article class="history-item">
      <small>${esc(new Date(x.time).toLocaleString(state.settings.lang==="hi"?"hi-IN":"en-IN"))}
      · ${esc(x.lang)} · ${esc(x.type)} ${x.typed?esc(tr("· typed","· टाइप किया")):""}</small>
      <p>${esc(x.text)}</p><div class="row">
      <button data-dwell data-replay="${x.id}">${T("Replay","दोबारा बोलें")}</button>
      <button data-dwell data-delete-history="${x.id}">${T("Delete","मिटाएँ")}</button></div>
    </article>`).join(""):`<p class="muted">${esc(tr("No messages here yet.","अभी कोई संदेश नहीं।"))}</p>`;
}
$("#historySearch").oninput=renderHistory;
$("#historyFilter").onchange=renderHistory;
$("#historyList").onclick=e=>{
  const replay=e.target.closest("[data-replay]");
  if(replay){const item=state.history.find(x=>x.id===replay.dataset.replay);if(item)speak(item.text,item.type,{record:false,lang:item.lang})}
  const del=e.target.closest("[data-delete-history]");
  if(del){state.history=state.history.filter(x=>x.id!==del.dataset.deleteHistory);save();renderHistory()}
};
$("#clearHistory").onclick=()=>confirmAction(tr("Delete all message history?","पूरा संदेश इतिहास मिटाएँ?"),()=>{
  state.history=[];save();renderHistory();
});
