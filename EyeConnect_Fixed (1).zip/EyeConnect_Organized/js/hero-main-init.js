/* ============================================================
   THREE.JS HERO AND GSAP SCROLL STORY
   ============================================================ */
let heroRenderer=null,heroScene=null,heroCamera=null,heroEye=null;
let heroKeys=null,heroWaves=null,heroParticles=null,heroProgress=0,heroVisible=true;
let heroResize=null,heroTrigger=null,heroPointer={x:0,y:0},storyStage=-1;
const heroResources=[];
function fallbackHero(){
  $("#scene").innerHTML='<div class="css-eye"></div>';
}
function labelTexture(text){
  const c=document.createElement("canvas");c.width=128;c.height=128;
  const ctx=c.getContext("2d");ctx.fillStyle="#102b43";ctx.fillRect(0,0,128,128);
  ctx.strokeStyle="#85ffe1";ctx.lineWidth=3;ctx.strokeRect(5,5,118,118);
  ctx.fillStyle="#e9fbff";ctx.font="bold 64px system-ui";ctx.textAlign="center";ctx.textBaseline="middle";
  ctx.fillText(text,64,67);
  const texture=new THREE.CanvasTexture(c);heroResources.push(texture);return texture;
}
function initHero(){
  const weak=(navigator.hardwareConcurrency&&navigator.hardwareConcurrency<=2)||
    (navigator.deviceMemory&&navigator.deviceMemory<=2);
  if(!window.THREE||!window.gsap||!window.ScrollTrigger||reduced.matches||weak){fallbackHero();return}
  try{
    const THREE=window.THREE;
    heroRenderer=new THREE.WebGLRenderer({alpha:true,antialias:true,powerPreference:"low-power"});
    heroRenderer.setPixelRatio(Math.min(devicePixelRatio,1.5));
    heroRenderer.setSize(innerWidth,$("#home").clientHeight);
    $("#scene").append(heroRenderer.domElement);
    heroScene=new THREE.Scene();
    heroScene.fog=new THREE.FogExp2(0x08111f,.035);
    heroCamera=new THREE.PerspectiveCamera(42,innerWidth/$("#home").clientHeight,.05,100);
    heroCamera.position.set(0,0,7.5);
    heroScene.add(new THREE.AmbientLight(0xadcfff,1.1));
    const light=new THREE.PointLight(0x82ffe1,50);light.position.set(3,3,5);heroScene.add(light);
    const rim=new THREE.PointLight(0x518aff,35);rim.position.set(-4,-2,3);heroScene.add(rim);
    heroEye=new THREE.Group();heroEye.position.x=innerWidth>800?1.35:.6;
    const white=new THREE.MeshPhysicalMaterial({color:0xe4f6ff,roughness:.24,metalness:.04,transparent:true});
    const ball=new THREE.Mesh(new THREE.SphereGeometry(1.45,56,40),white);
    heroEye.add(ball);
    const irisMat=new THREE.MeshStandardMaterial({color:0x19c9d5,emissive:0x087b98,emissiveIntensity:.9,roughness:.4,transparent:true});
    const iris=new THREE.Mesh(new THREE.CircleGeometry(.69,80),irisMat);iris.position.z=1.455;heroEye.add(iris);
    const pupil=new THREE.Mesh(new THREE.CircleGeometry(.30,64),new THREE.MeshBasicMaterial({color:0x010714,transparent:true}));
    pupil.position.z=1.47;heroEye.add(pupil);
    for(let i=0;i<70;i++){
      const angle=i/70*Math.PI*2;
      const spoke=new THREE.Mesh(new THREE.BoxGeometry(.018,.33,.008),
        new THREE.MeshBasicMaterial({color:i%2?0x84ffdf:0x11698c,transparent:true,opacity:.8}));
      spoke.position.set(Math.sin(angle)*.49,Math.cos(angle)*.49,1.463);spoke.rotation.z=-angle;
      heroEye.add(spoke);
    }
    const outer=new THREE.Mesh(new THREE.TorusGeometry(.70,.025,12,100),
      new THREE.MeshBasicMaterial({color:0x90ffe2,transparent:true}));
    outer.position.z=1.46;heroEye.add(outer);heroScene.add(heroEye);

    heroKeys=new THREE.Group();
    [..."QWERTYUIOPASDFGHJKLZXCVBNM"].forEach((letter,i)=>{
      const row=i<10?0:i<19?1:2,col=row===0?i:row===1?i-10:i-19;
      const mesh=new THREE.Mesh(new THREE.BoxGeometry(.47,.47,.11),
        new THREE.MeshStandardMaterial({map:labelTexture(letter),transparent:true,opacity:0,roughness:.45}));
      mesh.userData.target=new THREE.Vector3((col-(row===0?4.5:row===1?4:3))*.55,1-row*.6,0);
      mesh.userData.seed=i*.7;heroKeys.add(mesh);
    });
    heroKeys.position.set(.7,-.1,0);heroKeys.rotation.x=-.22;heroScene.add(heroKeys);
    heroWaves=new THREE.Group();
    for(let i=0;i<6;i++){
      const ring=new THREE.Mesh(new THREE.TorusGeometry(.35+i*.23,.018,8,80),
        new THREE.MeshBasicMaterial({color:i%2?0x7bf7dc:0x79adff,transparent:true,opacity:0}));
      ring.position.x=.9;heroWaves.add(ring);
    }
    heroScene.add(heroWaves);
    const positions=new Float32Array(500*3);
    for(let i=0;i<positions.length;i++)positions[i]=(Math.random()-.5)*24;
    const geo=new THREE.BufferGeometry();geo.setAttribute("position",new THREE.BufferAttribute(positions,3));
    heroParticles=new THREE.Points(geo,new THREE.PointsMaterial({color:0x93cce9,size:.025,transparent:true,opacity:.5}));
    heroScene.add(heroParticles);
    gsap.registerPlugin(ScrollTrigger);
    const obj={p:0};
    heroTrigger=gsap.to(obj,{p:1,ease:"none",scrollTrigger:{
      trigger:"#home",start:"top top",end:"+=220%",pin:true,scrub:1,
      onUpdate:self=>{heroProgress=self.progress}
    }});
    heroResize=()=>{
      if(!heroRenderer)return;
      heroRenderer.setSize(innerWidth,$("#home").clientHeight);
      heroCamera.aspect=innerWidth/$("#home").clientHeight;heroCamera.updateProjectionMatrix();
    };
    addEventListener("resize",heroResize);
    new IntersectionObserver(entries=>heroVisible=entries[0].isIntersecting).observe($("#home"));
    heroRenderer.domElement.addEventListener("webglcontextlost",e=>{
      e.preventDefault();heroVisible=false;
      heroTrigger?.scrollTrigger?.kill();heroTrigger?.kill();
      disposeHero();fallbackHero();
    });
  }catch{
    disposeHero();fallbackHero();
  }
}
function setGroupOpacity(group,opacity){
  group?.traverse(o=>{if(o.isMesh&&o.material){o.material.opacity=opacity;o.visible=opacity>.005}});
}
function heroFrame(now){
  if(!heroRenderer||!heroVisible||document.hidden)return;
  const p=heroProgress,t=now*.001;
  const zoom=clamp(p/.36,0,1);
  heroCamera.position.z=7.5-zoom*6.5;
  heroCamera.position.x=zoom*(innerWidth>800?1.35:.6);
  heroEye.rotation.y+=(heroPointer.x*.13-heroEye.rotation.y)*.035;
  heroEye.rotation.x+=(-heroPointer.y*.10-heroEye.rotation.x)*.035;
  heroEye.position.y=Math.sin(t*.65)*.08;
  setGroupOpacity(heroEye,1-clamp((p-.23)/.13,0,1));
  if(p>.32){
    const restore=clamp((p-.32)/.12,0,1);
    heroCamera.position.z=1+restore*6;
    heroCamera.position.x*=1-restore;
  }
  const keyIn=clamp((p-.34)/.18,0,1),keyOut=1-clamp((p-.62)/.12,0,1);
  heroKeys.children.forEach((key,i)=>{
    key.position.copy(key.userData.target);
    key.position.x+=(1-keyIn)*Math.sin(key.userData.seed)*5;
    key.position.y+=(1-keyIn)*Math.cos(key.userData.seed)*4;
    key.position.z+=(1-keyIn)*(i%4+1);
    key.rotation.z=(1-keyIn)*2;
    key.material.opacity=keyIn*keyOut;
    key.visible=key.material.opacity>.005;
  });
  heroKeys.rotation.y=Math.sin(t*.4)*.08;
  const waveAlpha=clamp((p-.68)/.12,0,1)*(1-clamp((p-.91)/.09,0,1));
  heroWaves.children.forEach((ring,i)=>{
    ring.material.opacity=waveAlpha*(.7+.3*Math.sin(t*2-i));
    ring.scale.setScalar(1+.08*Math.sin(t*2-i));
  });
  heroParticles.rotation.y=t*.015;
  const stage=p<.28?0:p<.65?1:p<.90?2:3;
  if(stage!==storyStage){
    storyStage=stage;
    const titles=[
      ["Your eyes.<br>Your voice.","आपकी आँखें।<br>आपकी आवाज़।"],
      ["A look.<br>A letter.","एक नज़र।<br>एक अक्षर।"],
      ["A sentence.<br>A connection.","एक वाक्य।<br>एक जुड़ाव।"],
      ["Your world.<br>Within reach.","आपकी दुनिया।<br>आपकी पहुँच में।"]
    ];
    const subtitles=[
      ["A look becomes a letter. A sentence becomes independence.","एक नज़र अक्षर बनती है। एक वाक्य आत्मनिर्भरता बनता है।"],
      ["Hold your gaze. Let your words take shape.","नज़र टिकाएँ। अपने शब्दों को आकार दें।"],
      ["Speak out loud, in English or Hindi.","अंग्रेज़ी या हिन्दी में अपनी बात कहें।"],
      ["Your communication space is waiting below.","आपका संवाद स्थान नीचे तैयार है।"]
    ];
    $("#heroTitle").innerHTML=tr(...titles[stage]);
    $("#heroSubtitle").textContent=tr(...subtitles[stage]);
  }
  heroRenderer.render(heroScene,heroCamera);
}
function disposeHero(){
  heroScene?.traverse(o=>{
    o.geometry?.dispose?.();
    const materials=Array.isArray(o.material)?o.material:o.material?[o.material]:[];
    materials.forEach(m=>m.dispose());
  });
  heroResources.forEach(r=>r.dispose());
  heroRenderer?.dispose();heroRenderer=null;
  if(heroResize)removeEventListener("resize",heroResize);
}
document.addEventListener("pointermove",e=>{
  heroPointer.x=e.clientX/innerWidth*2-1;heroPointer.y=e.clientY/innerHeight*2-1;
},{passive:true});

/* ============================================================
   MAIN LOOP: DETECTION THROTTLED TO ~25FPS, ONE DWELL LOOP
   ============================================================ */
let raf=0,lastFrame=performance.now(),statusAt=0,detectionErrors=0;
function frame(now){
  raf=requestAnimationFrame(frame);
  const dt=Math.min(now-lastFrame,100);lastFrame=now;
  if(document.hidden)return;
  heroFrame(now);
  if(mode==="camera"&&stream&&landmarker&&!trackingBusy&&
    video.readyState>=2&&now-lastDetection>40&&video.currentTime!==lastVideoTime){
    trackingBusy=true;lastDetection=now;lastVideoTime=video.currentTime;
    try{
      const result=landmarker.detectForVideo(video,now);
      readEyes(result,now);detectionErrors=0;
      if(calRun)calibrationFrame(now);
    }catch{
      detectionErrors++;eyesDetected=false;raw=null;resetDwell();
      if(detectionErrors>8){
        stopTracking();fallback(tr("Tracking stopped after repeated camera errors. Try restarting or use simulated gaze.","बार-बार कैमरा त्रुटि के कारण ट्रैकिंग रुकी। दोबारा शुरू करें या नकली नज़र मोड चुनें।"));
      }
    }finally{trackingBusy=false}
  }
  let target=null;
  if(mode==="sim")target=sim;
  if(mode==="camera"&&eyesDetected&&now-lastEyeTime<250)target=mappedGaze();
  pointValid=!!target;
  if(target){
    const gain=mode==="camera"?state.settings.gain:1;
    const tx=clamp(innerWidth/2+(target.x-innerWidth/2)*gain,4,innerWidth-4);
    const ty=clamp(innerHeight/2+(target.y-innerHeight/2)*gain,4,innerHeight-4);
    // Frame-rate-independent EMA. Larger smoothing means more inertia.
    const base=mode==="sim"?.40:1-state.settings.smooth;
    const alpha=1-Math.pow(1-base,dt/(1000/60));
    gaze.x+=(tx-gaze.x)*alpha;gaze.y+=(ty-gaze.y)*alpha;
    cursor.style.display="block";cursor.style.left=gaze.x+"px";cursor.style.top=gaze.y+"px";
    const test=$("#testArea").getBoundingClientRect();
    $("#testDot").style.left=clamp((gaze.x-test.left)/test.width*100,3,97)+"%";
    $("#testDot").style.top=clamp((gaze.y-test.top)/test.height*100,7,93)+"%";
  }else cursor.style.display="none";
  // During calibration, only the cancel control can be selected.
  // Calibration cannot click through to the page below its modal.
  dwellFrame(now,gaze.x,gaze.y,pointValid&&!calRun);
  if(now-statusAt>600){statusAt=now;updateStatus()}
}

/* ============================================================
   INITIALIZATION, REVEAL FLOW AND CLEANUP
   ============================================================ */
buildSettings();applyLanguage();renderCameraList();clearEyeView();
renderVoices();renderSOSSettings();updateSession();renderPractice();
enhanceControls(document);
initHero();
let revealDone=false;
const revealObserver=new IntersectionObserver(entries=>{
  if(!entries.some(e=>e.isIntersecting)||revealDone)return;
  revealDone=true;
  if(window.gsap&&!reduced.matches){
    gsap.fromTo("#dashboard .dashboard-grid",{y:70,opacity:.1},{y:0,opacity:1,duration:.9,ease:"power3.out"});
  }
  if(!authOffered){
    setTimeout(()=>{
      if(!authOffered&&!$$("dialog[open]").length)openAuth("signup");
    },1100);
  }
},{threshold:.18});
revealObserver.observe($("#dashboard"));

document.addEventListener("visibilitychange",()=>{
  resetDwell();
  if(document.hidden){
    if(calRun)cancelCalibration();
    if(speechAvailable)speechSynthesis.cancel();
  }
});
let resizeTimer;
addEventListener("resize",()=>{
  clearTimeout(resizeTimer);
  resizeTimer=setTimeout(()=>{
    if(calibration){
      calibration=null;
      toast(tr("Screen geometry changed. Please recalibrate.","स्क्रीन का आकार बदला है। दोबारा कैलिब्रेट करें।"));
    }
    if(calRun)cancelCalibration();
    resetDwell();
  },350);
});
function cleanup(){
  cancelAnimationFrame(raf);clearTimeout(typedTimer);clearTimeout(toastTimer);
  clearTimeout(resizeTimer);
  stream?.getTracks().forEach(t=>t.stop());stream=null;
  video.pause();video.srcObject=null;
  cancelSOS();
  try{landmarker?.close()}catch{}
  landmarker=null;visionPromise=null;
  try{audioContext?.close()}catch{}
  disposeHero();heroTrigger?.scrollTrigger?.kill();heroTrigger?.kill();
  revealObserver.disconnect();
}
addEventListener("pagehide",cleanup,{once:true});
addEventListener("pageshow",e=>{if(e.persisted)location.reload()});
raf=requestAnimationFrame(frame);