/* ============================================================
   TRACKER: PINNED TASKS VISION, CAMERA LIFECYCLE, EYE-ONLY DRAWING
   A detached video is never inserted into the DOM.
   MediaPipe still consumes the full camera frame internally.
   ============================================================ */
const video=document.createElement("video");
video.muted=true;video.autoplay=true;video.playsInline=true;
let landmarker=null,visionPromise=null,stream=null,starting=false,cameraGeneration=0;
let mode="mouse",eyesDetected=false,quality="poor",tip="",raw=null;
let latestLandmarks=null,lastVideoTime=-1,lastDetection=0,lastEyeTime=0;
let gaze={x:innerWidth/2,y:innerHeight/2},sim={x:innerWidth/2,y:innerHeight/2};
let calibration=null,calRun=null,lastBlink=0,trackingBusy=false;
const eyeCtx=$("#eyeCanvas").getContext("2d");
const MODEL="https://storage.googleapis.com/mediapipe-models/face_landmarker/face_landmarker/float16/1/face_landmarker.task";
async function getVision(){
  if(landmarker)return landmarker;
  if(!visionPromise)visionPromise=(async()=>{
    const {FaceLandmarker,FilesetResolver}=await import(
      "https://cdn.jsdelivr.net/npm/@mediapipe/tasks-vision@0.10.14/vision_bundle.mjs");
    const files=await FilesetResolver.forVisionTasks(
      "https://cdn.jsdelivr.net/npm/@mediapipe/tasks-vision@0.10.14/wasm");
    const base={baseOptions:{modelAssetPath:MODEL,delegate:"GPU"},runningMode:"VIDEO",
      numFaces:1,outputFaceBlendshapes:true,
      minFaceDetectionConfidence:.5,minFacePresenceConfidence:.5,minTrackingConfidence:.5};
    try{return await FaceLandmarker.createFromOptions(files,base)}
    catch{return await FaceLandmarker.createFromOptions(files,{
      ...base,baseOptions:{modelAssetPath:MODEL,delegate:"CPU"}
    })}
  })();
  try{landmarker=await visionPromise;return landmarker}
  catch(e){visionPromise=null;throw e}
}
function clearEyeView(){
  eyeCtx.fillStyle="#050b14";eyeCtx.fillRect(0,0,640,200);
  eyeCtx.fillStyle="#d4e7f9";eyeCtx.font="22px system-ui";eyeCtx.textAlign="center";
  eyeCtx.fillText(tr("Eye view appears here","आँखों का दृश्य यहाँ दिखेगा"),320,105);
}
function updateStatus(){
  const cameraOn=!!stream;
  const q=quality==="good"?tr("Good","अच्छी"):quality==="fair"?tr("Fair","मध्यम"):tr("Poor","कमज़ोर");
  $("#trackerStatus").innerHTML=
    `<div><span>${esc(tr("Camera","कैमरा"))}</span><strong>${esc(tr(cameraOn?"On":"Off",cameraOn?"चालू":"बंद"))}</strong></div>
     <div><span>${esc(tr("Eyes","आँखें"))}</span><strong>${esc(tr(eyesDetected?"Detected":"Not detected",eyesDetected?"मिल गईं":"नहीं मिलीं"))}</strong></div>
     <div><span>${esc(tr("Tracking quality","ट्रैकिंग गुणवत्ता"))}</span><strong>${esc(q)}</strong></div>`;
  $("#trackerTip").textContent=tip||tr("Use even light and keep your head comfortably still.","समान रोशनी रखें और सिर आराम से स्थिर रखें।");
  $("#modeBadge").textContent=mode==="camera"?tr("Camera gaze","कैमरे से नज़र"):mode==="sim"?tr("SIMULATED · pointer follows mouse/touch","नकली मोड · पॉइंटर माउस/टच के साथ"):tr("Mouse / touch","माउस / टच");
}
async function renderCameraList(){
  const select=$("#cameraSelect");
  try{
    const devices=await navigator.mediaDevices?.enumerateDevices?.()||[];
    const cams=devices.filter(x=>x.kind==="videoinput");
    select.innerHTML=`<option value="">${esc(tr("Default camera","डिफ़ॉल्ट कैमरा"))}</option>`+
      cams.map((x,i)=>`<option value="${esc(x.deviceId)}">${esc(x.label||tr("Camera ","कैमरा ")+(i+1))}</option>`).join("");
    select.value=state.settings.camera;
  }catch{
    select.innerHTML=`<option value="">${esc(tr("Camera list unavailable","कैमरा सूची उपलब्ध नहीं"))}</option>`;
  }
}
$("#cameraSelect").onchange=async e=>{
  state.settings.camera=e.target.value;save();
  if(stream){stopTracking();await startTracking()}
};
async function startTracking(){
  if(starting)return;
  if(!navigator.mediaDevices?.getUserMedia){
    fallback(tr("Camera access needs a supported browser and usually localhost or HTTPS.","कैमरे के लिए समर्थित ब्राउज़र और आम तौर पर localhost या HTTPS चाहिए।"));return;
  }
  starting=true;const generation=++cameraGeneration;
  $("#startCamera").disabled=true;
  tip=tr("Loading the on-device model…","डिवाइस पर चलने वाला मॉडल लोड हो रहा है…");updateStatus();
  let acquired=null;
  try{
    const constraints={width:{ideal:640},height:{ideal:480},
      ...(state.settings.camera?{deviceId:{exact:state.settings.camera}}:{facingMode:"user"})};
    acquired=await navigator.mediaDevices.getUserMedia({audio:false,video:constraints});
    if(generation!==cameraGeneration){acquired.getTracks().forEach(t=>t.stop());return}
    stream=acquired;video.srcObject=stream;await video.play();
    await getVision();
    if(generation!==cameraGeneration)return;
    mode="camera";calibration=null;lastVideoTime=-1;raw=null;
    tip=tr("Find a comfortable position. Calibration will begin.","आरामदायक स्थिति में बैठें। कैलिब्रेशन शुरू होगा।");
    await renderCameraList();updateStatus();startCalibration();
  }catch(e){
    acquired?.getTracks().forEach(t=>t.stop());
    if(generation!==cameraGeneration)return;
    stream=null;video.srcObject=null;
    fallback(e.name==="NotAllowedError"
      ?tr("Camera permission was denied. Mouse/touch works now; simulated gaze is also available.","कैमरे की अनुमति नहीं मिली। माउस/टच काम करता है; नकली नज़र मोड भी उपलब्ध है।")
      :tr("Camera or model could not start. Check permissions, network, camera selection, and lighting. Mouse/touch remains available.","कैमरा या मॉडल शुरू नहीं हुआ। अनुमति, नेटवर्क, कैमरा और रोशनी जाँचें। माउस/टच उपलब्ध है।"));
  }finally{
    if(generation===cameraGeneration){starting=false;$("#startCamera").disabled=false}
  }
}
function stopTracking(){
  ++cameraGeneration;starting=false;$("#startCamera").disabled=false;
  stream?.getTracks().forEach(track=>track.stop());stream=null;
  video.pause();video.srcObject=null;
  mode="mouse";raw=null;eyesDetected=false;quality="poor";
  calibration=null;latestLandmarks=null;lastVideoTime=-1;
  if(calRun)cancelCalibration();
  clearEyeView();resetDwell();updateStatus();
}
function fallback(message){
  mode="mouse";eyesDetected=false;quality="poor";tip=message;
  clearEyeView();updateStatus();toast(message);
}
function simulation(){
  stopTracking();mode="sim";tip=tr(
    "Demonstration only: move the mouse or slide a finger; hold still to dwell. Arrow keys move the simulated pointer.",
    "केवल डेमो: माउस या उँगली चलाएँ; चयन के लिए स्थिर रहें। तीर कुंजियों से नकली पॉइंटर चलाएँ।");
  gaze={...sim};updateStatus();toast(tip);
}
$("#simulateButton").onclick=simulation;
$("#mouseButton").onclick=()=>{stopTracking();tip=tr("Standard mouse and touch controls are active.","सामान्य माउस और टच नियंत्रण चालू हैं।");updateStatus()};
$("#startCamera").onclick=()=>$("#permissionDialog").showModal();
$("#authCamera").onclick=()=>$("#permissionDialog").showModal();
$("#authSim").onclick=simulation;
$("#stopCamera").onclick=stopTracking;
$("#permissionAccept").onclick=()=>{$("#permissionDialog").close();startTracking()};
$("#permissionSim").onclick=()=>{$("#permissionDialog").close();simulation()};

function distance(a,b){return Math.hypot(a.x-b.x,a.y-b.y)}
function irisFeature(lm,ids){
  const [a,b,top,bottom,iris]=ids.map(i=>lm[i]);
  // Source-image corner ordering is explicit; the preview is NOT mirrored.
  const left=a.x<b.x?a:b,right=a.x<b.x?b:a;
  const dx=right.x-left.x,dy=right.y-left.y,w2=dx*dx+dy*dy;
  if(w2<1e-7)return null;
  const cx=(left.x+right.x)/2,cy=(left.y+right.y)/2;
  return{
    x:((iris.x-left.x)*dx+(iris.y-left.y)*dy)/w2,
    y:((iris.x-cx)*(-dy)+(iris.y-cy)*dx)/w2,
    openness:distance(top,bottom)/Math.sqrt(w2),
    width:Math.sqrt(w2)
  };
}
const eyeIndices=[
  [33,133,159,145,468],
  [362,263,386,374,473]
];
function readEyes(result,now){
  const lm=result.faceLandmarks?.[0];
  latestLandmarks=lm||null;
  if(!lm){
    eyesDetected=false;quality="poor";raw=null;
    tip=tr("Eyes not found. Face the camera and improve lighting.","आँखें नहीं मिलीं। कैमरे की ओर देखें और रोशनी सुधारें।");
    clearEyeView();resetDwell();return;
  }
  const features=eyeIndices.map(ids=>irisFeature(lm,ids));
  if(features.some(f=>!f)){eyesDetected=false;raw=null;return}
  const blends=result.faceBlendshapes?.[0]?.categories||[];
  const blinkScore=Math.max(0,...blends.filter(c=>c.categoryName==="eyeBlinkLeft"||c.categoryName==="eyeBlinkRight").map(c=>c.score));
  const open=Math.min(...features.map(f=>f.openness));
  const closed=open<.085||blinkScore>.55;
  if(closed)lastBlink=now;
  // Gross closure is always rejected. The optional blink filter adds a
  // 250ms post-blink guard. No wink/blink is mapped to a click.
  const blocked=closed||(state.settings.blink&&now-lastBlink<250);
  eyesDetected=!blocked;
  if(blocked){raw=null;resetDwell()}
  else{
    raw={x:(features[0].x+features[1].x)/2,y:(features[0].y+features[1].y)/2};
    lastEyeTime=now;
  }
  quality=blocked?"poor":features.every(f=>f.width>.035)&&blinkScore<.25?"good":"fair";
  tip=blocked?tr("Blink paused selection.","पलक झपकने पर चयन रुका।"):
    quality==="good"?tr("Eyes found. Look naturally; keep your head fairly still.","आँखें मिल गईं। स्वाभाविक रूप से देखें; सिर अपेक्षाकृत स्थिर रखें।"):
    tr("Move a little closer, reduce glare, and improve even lighting.","थोड़ा पास आएँ, चकाचौंध कम करें और रोशनी सुधारें।");
  drawEyes(lm);
}
function drawEyes(lm){
  const W=video.videoWidth,H=video.videoHeight;
  if(!W||!H)return;
  eyeCtx.fillStyle="#050b14";eyeCtx.fillRect(0,0,640,200);
  // Separate tight eye crops avoid showing a continuous face strip/nose.
  // Sort by camera x so the composite preserves source-image left/right.
  const groups=[
    [33,133,159,145,160,158,153,144,468],
    [362,263,386,374,385,387,380,373,473]
  ].map(ids=>ids.map(i=>lm[i])).sort((a,b)=>a.at(-1).x-b.at(-1).x);
  groups.forEach((points,i)=>{
    const xs=points.map(p=>p.x*W),ys=points.map(p=>p.y*H);
    const width=Math.max(...xs)-Math.min(...xs),height=Math.max(...ys)-Math.min(...ys);
    const x=clamp(Math.min(...xs)-width*.12,0,W-1);
    const y=clamp(Math.min(...ys)-height*.35,0,H-1);
    const cw=Math.min(W-x,width*1.24),ch=Math.min(H-y,Math.max(height*1.7,width*.25));
    const box={x:i*320+8,y:15,w:304,h:170};
    const scale=Math.min(box.w/cw,box.h/ch);
    const dw=cw*scale,dh=ch*scale,ox=box.x+(box.w-dw)/2,oy=box.y+(box.h-dh)/2;
    // No scale(-1,1), CSS mirroring, or other image inversion.
    eyeCtx.drawImage(video,x,y,cw,ch,ox,oy,dw,dh);
    const iris=points.at(-1);
    eyeCtx.beginPath();eyeCtx.arc(ox+(iris.x*W-x)*scale,oy+(iris.y*H-y)*scale,5,0,Math.PI*2);
    eyeCtx.fillStyle="#70ffdc";eyeCtx.fill();
  });
}

/* ============================================================
   CALIBRATION: NINE MEDIAN SAMPLES, AFFINE LEAST SQUARES
   ============================================================ */
const calibrationDots=[
  [.12,.16],[.5,.16],[.88,.16],
  [.88,.5],[.5,.5],[.12,.5],
  [.12,.84],[.5,.84],[.88,.84]
];
const median=values=>{const a=[...values].sort((a,b)=>a-b);return a[Math.floor(a.length/2)]};
function startCalibration(){
  if(!stream||mode!=="camera"){toast(tr("Enable the camera first, or use simulated gaze.","पहले कैमरा चालू करें या नकली नज़र मोड इस्तेमाल करें।"));return}
  resetDwell();
  calRun={index:0,since:performance.now(),samples:[],points:[]};
  if(!$("#calDialog").open)$("#calDialog").showModal();
  positionCalibrationDot();
}
function positionCalibrationDot(){
  const p=calibrationDots[calRun.index];
  $("#calDot").style.left=p[0]*100+"%";$("#calDot").style.top=p[1]*100+"%";
  $("#calInfo").textContent=tr(
    `Dot ${calRun.index+1} of 9. Look at the dot; keep your head still. Waiting for open eyes.`,
    `बिंदु ${calRun.index+1}/9। बिंदु देखें; सिर स्थिर रखें। खुली आँखों का इंतज़ार है।`);
}
function calibrationFrame(now){
  if(!calRun)return;
  if(raw&&eyesDetected&&now-calRun.since>450){
    calRun.samples.push({...raw});
  }
  if(calRun.samples.length<18 || now-calRun.since<1550)return;
  const p=calibrationDots[calRun.index];
  calRun.points.push({
    x:median(calRun.samples.map(s=>s.x)),y:median(calRun.samples.map(s=>s.y)),
    targetX:p[0],targetY:p[1]
  });
  calRun.index++;
  if(calRun.index<calibrationDots.length){
    calRun.since=now;calRun.samples=[];positionCalibrationDot();return;
  }
  const points=calRun.points;
  calRun=null;$("#calDialog").close();
  const meanX=points.reduce((s,p)=>s+p.x,0)/points.length;
  const meanY=points.reduce((s,p)=>s+p.y,0)/points.length;
  const scaleX=Math.max(...points.map(p=>p.x))-Math.min(...points.map(p=>p.x));
  const scaleY=Math.max(...points.map(p=>p.y))-Math.min(...points.map(p=>p.y));
  if(scaleX<.008||scaleY<.004){
    calibration=null;toast(tr("Not enough eye movement was measured. Recalibrate with your head still, or use simulated gaze.","आँखों की पर्याप्त गति नहीं मापी गई। सिर स्थिर रखकर दोबारा करें या नकली नज़र मोड चुनें।"));return;
  }
  const feature=p=>[1,(p.x-meanX)/scaleX,(p.y-meanY)/scaleY];
  const matrix=Array.from({length:3},()=>[0,0,0]),bx=[0,0,0],by=[0,0,0];
  points.forEach(p=>{
    const f=feature(p);
    for(let i=0;i<3;i++){
      bx[i]+=f[i]*p.targetX;by[i]+=f[i]*p.targetY;
      for(let j=0;j<3;j++)matrix[i][j]+=f[i]*f[j];
    }
  });
  for(let i=0;i<3;i++)matrix[i][i]+=.0001;
  const cx=solve(matrix,bx),cy=solve(matrix,by);
  if(!cx||!cy){toast(tr("Calibration could not fit. Please try again.","कैलिब्रेशन नहीं हो सका। फिर कोशिश करें।"));return}
  calibration={cx,cy,meanX,meanY,scaleX,scaleY};
  const error=points.reduce((s,p)=>{
    const f=feature(p),x=dot(cx,f),y=dot(cy,f);
    return s+Math.hypot(x-p.targetX,y-p.targetY);
  },0)/points.length;
  if(error>.2){
    calibration=null;
    toast(tr("Calibration was too inconsistent. Try again with larger, deliberate eye movements.","कैलिब्रेशन बहुत असंगत था। स्पष्ट, बड़ी आँखों की गति से फिर कोशिश करें।"));
    return;
  }
  gaze={x:innerWidth/2,y:innerHeight/2};lastBlink=performance.now();
  toast(tr("Calibration saved for this session. Test left, right, up, and down before typing.","इस सत्र का कैलिब्रेशन तैयार है। टाइपिंग से पहले बाएँ, दाएँ, ऊपर और नीचे जाँचें।"));
  emit("calibrated");
}
function solve(A,b){
  const m=A.map((row,i)=>[...row,b[i]]);
  for(let i=0;i<3;i++){
    let pivot=i;
    for(let r=i+1;r<3;r++)if(Math.abs(m[r][i])>Math.abs(m[pivot][i]))pivot=r;
    [m[i],m[pivot]]=[m[pivot],m[i]];
    if(Math.abs(m[i][i])<1e-10)return null;
    const d=m[i][i];for(let j=i;j<4;j++)m[i][j]/=d;
    for(let r=0;r<3;r++)if(r!==i){
      const f=m[r][i];for(let j=i;j<4;j++)m[r][j]-=f*m[i][j];
    }
  }
  return m.map(r=>r[3]);
}
const dot=(a,b)=>a.reduce((s,x,i)=>s+x*b[i],0);
function cancelCalibration(){
  calRun=null;if($("#calDialog").open)$("#calDialog").close();resetDwell();
}
$("#calCancel").onclick=cancelCalibration;
$("#calDialog").addEventListener("cancel",()=>{calRun=null;resetDwell()});
$$(".calibrate").forEach(b=>b.onclick=startCalibration);
function mappedGaze(){
  if(!raw)return null;
  if(!calibration){
    // An unmirrored user-facing camera sees the user's right as IMAGE
    // left. Thus the provisional screen-X mapping has a NEGATIVE sign.
    // Source-image down is screen down, so provisional Y is positive.
    // Actual calibration learns BOTH signs and cross-axis coupling from
    // labelled screen targets: no extra post-calibration flip is applied.
    return{x:innerWidth*(.5-(raw.x-.5)*5),y:innerHeight*(.5+raw.y*6)};
  }
  const c=calibration,f=[1,(raw.x-c.meanX)/c.scaleX,(raw.y-c.meanY)/c.scaleY];
  return{x:dot(c.cx,f)*innerWidth,y:dot(c.cy,f)*innerHeight};
}
// Deterministic sign sanity check for the provisional mapping.
// This does not replace testing with a real person/camera.
const signCheck=(.5-(.4-.5)*5)>(.5-(.6-.5)*5);
if(!signCheck)throw new Error("Gaze sign sanity check failed");
