/* ============================================================
   ONE REUSABLE DWELL ENGINE
   ============================================================ */
let dwellTarget=null,dwellSince=0,dwellFired=false,lastScrollRepeat=0;
let pointValid=false,lastPointer={x:innerWidth/2,y:innerHeight/2};
const dwellRing=$("#dwellRing"),ringFill=$("#dwellRing .fill"),cursor=$("#cursor");
function resetDwell(){
  if(dwellTarget)dwellTarget.removeAttribute("data-dwelling");
  dwellTarget=null;dwellSince=0;dwellFired=false;
  dwellRing.style.display="none";
}
function activate(el){
  if(!el?.isConnected||el.disabled)return;
  if(isTextField(el)){
    activeInput=el;el.focus({preventScroll:true});renderSuggestions();
  }else if(el.tagName==="SELECT"){
    // Native select popups aren't reliably controllable by synthetic
    // clicks. Adjacent +/- controls provide deterministic gaze access.
    el.focus({preventScroll:true});
    toast(tr("Use the − and + buttons below to change this option.","विकल्प बदलने के लिए नीचे − और + बटन इस्तेमाल करें।"));
  }else el.click();
}
function dwellFrame(now,x,y,valid){
  if(!valid){resetDwell();return}
  const found=document.elementFromPoint(x,y)?.closest("[data-dwell]");
  const el=found&&!found.disabled&&!found.closest("[hidden]")?found:null;
  if(el!==dwellTarget){
    if(dwellTarget&& !dwellFired && now-dwellSince>300)emit("miss");
    resetDwell();
    if(el){dwellTarget=el;dwellSince=now;el.setAttribute("data-dwelling","")}
  }
  if(!el)return;
  const rect=el.getBoundingClientRect();
  dwellRing.style.display="block";
  dwellRing.style.left=clamp(rect.left+rect.width/2,32,innerWidth-32)+"px";
  dwellRing.style.top=clamp(rect.top+rect.height/2,32,innerHeight-32)+"px";
  const duration=state.settings.dwell*1000;
  const progress=clamp((now-dwellSince)/duration,0,1);
  ringFill.style.strokeDashoffset=String(176*(1-progress));
  if(!dwellFired&&progress===1){
    dwellFired=true;lastScrollRepeat=now;
    emit("selection",{milliseconds:now-dwellSince,element:el});
    activate(el);
  }else if(dwellFired&&el.dataset.scroll&&now-lastScrollRepeat>650){
    lastScrollRepeat=now;activate(el);
  }
  // Other controls deliberately require leaving and re-entering.
  // This prevents accidental repeated SOS, purchases, deletes, etc.
}
document.addEventListener("pointermove",e=>{
  lastPointer={x:e.clientX,y:e.clientY};
  if(mode==="sim")sim={...lastPointer};
},{passive:true});
document.addEventListener("touchmove",e=>{
  if(mode!=="sim")return;
  const p=e.touches[0];if(p)sim={x:p.clientX,y:p.clientY};
},{passive:true});
document.addEventListener("keydown",e=>{
  if(e.key==="Escape"){cancelSOS();resetDwell()}
  if(mode!=="sim"||isTextField(e.target))return;
  const delta={ArrowLeft:[-25,0],ArrowRight:[25,0],ArrowUp:[0,-25],ArrowDown:[0,25]}[e.key];
  if(delta){e.preventDefault();sim.x=clamp(sim.x+delta[0],0,innerWidth);sim.y=clamp(sim.y+delta[1],0,innerHeight)}
});
document.addEventListener("pointerdown",e=>{
  unlockAudio();
  // A deliberate physical click resets dwell to avoid double selection.
  if(e.isTrusted)resetDwell();
},{passive:true});

function scrollAction(dir){
  if(dir==="up"||dir==="down"){
    window.scrollBy({top:(dir==="up"?-1:1)*innerHeight*.55,behavior:motion()});return;
  }
  const win=$("#keyboardDock").closest("#dashboard")?$(".keyboard-window"):null;
  const dash=$("#dashboard").getBoundingClientRect();
  if(win&&dash.top<innerHeight*.55&&dash.bottom>innerHeight*.4&&win.scrollWidth>win.clientWidth){
    win.scrollBy({left:(dir==="left"?-1:1)*280,behavior:motion()});return;
  }
  const current=sections.reduce((best,[id],i)=>{
    const d=Math.abs($("#"+id).getBoundingClientRect().top-110);
    return d<best.d?{d,i}:best;
  },{d:Infinity,i:0}).i;
  go(sections[clamp(current+(dir==="left"?-1:1),0,sections.length-1)][0]);
}
$$("[data-scroll]").forEach(b=>b.onclick=()=>scrollAction(b.dataset.scroll));

/* ============================================================
   SOS: LOCAL ALARM, DISPLAY-ONLY CONTACT, SAFE PRACTICE MODE
   ============================================================ */
let audioContext=null,alarmOsc=null,alarmGain=null,alarmTimer=null;
function unlockAudio(){
  try{
    const AC=window.AudioContext||window.webkitAudioContext;
    if(!AC)return;
    audioContext ||= new AC();
    if(audioContext.state==="suspended")audioContext.resume().catch(()=>{});
  }catch{}
}
function startAlarm(){
  try{
    unlockAudio();if(!audioContext)return;
    alarmOsc=audioContext.createOscillator();alarmGain=audioContext.createGain();
    alarmOsc.type="sine";alarmGain.gain.value=.28;
    alarmOsc.connect(alarmGain);alarmGain.connect(audioContext.destination);
    alarmOsc.frequency.value=740;alarmOsc.start();
    let high=false;
    alarmTimer=setInterval(()=>{
      high=!high;
      alarmOsc?.frequency.setTargetAtTime(high?1000:740,audioContext.currentTime,.08);
    },650);
  }catch{toast(tr("Audio alarm was blocked. The visual SOS remains active.","ध्वनि अलार्म रोक दिया गया। दृश्य SOS चालू है।"))}
}
function renderSOSSettings(){
  const lang=state.settings.lang,list=state.settings.sos[lang];
  $("#sosSelect").innerHTML=list.map((x,i)=>`<option value="${i}">${esc(x)}</option>`).join("");
  $("#sosSelect").value=String(clamp(state.settings.sosIndex,0,list.length-1));
  $("#sosEditors").innerHTML=list.map((x,i)=>`<button data-dwell data-sos-edit="${i}">${esc(tr("Edit: ","संपादित करें: ")+x)}</button>`).join("");
  $("#contactName").value=state.settings.contactName;
  $("#contactNumber").value=state.settings.contactNumber;
}
$("#sosSelect").onchange=e=>{state.settings.sosIndex=Number(e.target.value);save()};
$("#sosEditors").onclick=e=>{
  const b=e.target.closest("[data-sos-edit]");if(!b)return;
  const lang=state.settings.lang,i=Number(b.dataset.sosEdit);
  openEditor(tr("Edit SOS message","SOS संदेश बदलें"),state.settings.sos[lang][i],text=>{
    state.settings.sos[lang][i]=text;save();renderSOSSettings();
  });
};
["contactName","contactNumber"].forEach(id=>$("#"+id).oninput=e=>{
  state.settings[id]=e.target.value;save();
});
function triggerSOS(){
  if(practice.active){
    toast(tr("Practice SOS complete. No alarm and no alert.","अभ्यास SOS पूरा। न अलार्म, न अलर्ट।"));
    emit("sos");return;
  }
  cancelSOS();
  const text=state.settings.sos[state.settings.lang][state.settings.sosIndex]||
    defaults.sos[state.settings.lang][0];
  $("#emergencyMessage").textContent=text;
  $("#emergencyContact").textContent=[state.settings.contactName,state.settings.contactNumber].filter(Boolean).join(" · ")||
    tr("No emergency contact configured.","आपातकालीन संपर्क नहीं जोड़ा गया।");
  $("#emergencyDialog").showModal();
  $("#emergencyDialog").classList.add("activeAlarm");
  startAlarm();speak(text,"sos");
}
function cancelSOS(){
  clearInterval(alarmTimer);alarmTimer=null;
  if(alarmOsc){try{alarmOsc.stop();alarmOsc.disconnect()}catch{}alarmOsc=null}
  if(alarmGain){try{alarmGain.disconnect()}catch{}alarmGain=null}
  if($("#emergencyDialog").open)$("#emergencyDialog").close();
  $("#emergencyDialog").classList.remove("activeAlarm");
  if(speechAvailable)speechSynthesis.cancel();
  resetDwell();
}
$("#sosButton").onclick=triggerSOS;
$("#cancelSOS").onclick=cancelSOS;
$("#emergencyDialog").addEventListener("cancel",e=>{e.preventDefault();cancelSOS()});

/* ============================================================
   PRACTICE: EVENT-DRIVEN STEPS, SHRINKING TARGETS AND SCORE
   ============================================================ */
const practice={active:false,step:0,hits:0,selections:0,misses:0,totalTime:0,started:0};
const practiceCopy=[
  ["Camera and calibration","कैमरा और कैलिब्रेशन",
   "Enable the camera and complete calibration. You can skip this step to practice with simulated gaze.",
   "कैमरा चालू करके कैलिब्रेशन पूरा करें। नकली नज़र से अभ्यास के लिए यह चरण छोड़ सकते हैं।"],
  ["Hold on the target","लक्ष्य पर नज़र टिकाएँ",
   "Select the round target three times. Look away between selections; it gets smaller each time.",
   "गोल लक्ष्य को तीन बार चुनें। हर चयन के बीच नज़र हटाएँ; लक्ष्य छोटा होता जाएगा।"],
  ["Type a short word","छोटा शब्द टाइप करें",
   "Go to the dashboard and type “hi” using the keyboard.",
   "डैशबोर्ड पर जाकर कीबोर्ड से “नमस्ते” टाइप करें।"],
  ["Try a suggestion","सुझाव आज़माएँ",
   "Select any word suggestion above the keyboard.",
   "कीबोर्ड के ऊपर कोई शब्द सुझाव चुनें।"],
  ["Speak a sentence","वाक्य बोलें",
   "Add a few words, then select Speak.",
   "कुछ शब्द जोड़ें और बोलें चुनें।"],
  ["Use a quick phrase","तुरंत वाक्य बोलें",
   "Select a ready-made phrase on the dashboard.",
   "डैशबोर्ड पर तैयार वाक्य चुनें।"],
  ["Try the safe SOS","सुरक्षित SOS आज़माएँ",
   "Select the red SOS button. Practice suppresses the alarm and does not send anything.",
   "लाल SOS बटन चुनें। अभ्यास में अलार्म नहीं बजेगा और कुछ भेजा नहीं जाएगा।"]
];
function renderPractice(){
  $("#practiceProgress").value=practice.active?practice.step:practice.step===7?7:0;
  const item=practiceCopy[Math.min(practice.step,6)];
  $("#practiceTitle").textContent=practice.step===7
    ?tr("You did it. Your voice is ready.","बहुत बढ़िया। आपकी आवाज़ तैयार है।")
    :`${practice.step+1}/7 · ${tr(item[0],item[1])}`;
  $("#practiceHelp").textContent=practice.step===7
    ?tr("Repeat whenever you want. Adjust dwell time if a selection feels rushed.","जब चाहें दोहराएँ। चयन जल्दी लगे तो नज़र टिकाने का समय बढ़ाएँ।")
    :tr(item[2],item[3]);
  $("#practiceTarget").hidden=!(practice.active&&practice.step===1);
  const sizes=[160,112,64];
  $("#practiceTarget").style.width=$("#practiceTarget").style.height=sizes[Math.min(practice.hits,2)]+"px";
  const total=practice.selections+practice.misses;
  $("#practiceScore").textContent=tr("Selection score","चयन स्कोर")+`: ${total?Math.round(practice.selections/total*100):0}% · `+
    tr("average","औसत")+` ${practice.selections?(practice.totalTime/practice.selections/1000).toFixed(1):"0.0"}s`;
  $("#practiceAction").textContent=practice.step===0?tr("Camera / calibrate","कैमरा / कैलिब्रेट"):tr("Open dashboard","डैशबोर्ड खोलें");
}
function nextPractice(){
  if(!practice.active)return;
  practice.step++;practice.hits=0;
  if(practice.step>=7){practice.active=false;practice.step=7;go("practice")}
  toast(tr("Great work. Next step!","बहुत अच्छा। अगला चरण!"));renderPractice();
}
$("#practiceStart").onclick=()=>{
  Object.assign(practice,{active:true,step:0,hits:0,selections:0,misses:0,totalTime:0,started:performance.now()});
  renderPractice();
};
$("#practiceAction").onclick=()=>{
  if(practice.step===0){
    if(stream)startCalibration();else $("#permissionDialog").showModal();
  }else{go("dashboard");if(practice.step===2){activeInput=mainTarget;replaceInput("")}}
};
$("#practiceSkip").onclick=nextPractice;
$("#practiceEnd").onclick=()=>{practice.active=false;renderPractice();toast(tr("Practice ended. SOS now uses the real local alarm.","अभ्यास समाप्त। SOS अब वास्तविक स्थानीय अलार्म बजाएगा।"))};
$("#practiceTarget").onclick=()=>{
  if(practice.active&&practice.step===1){
    practice.hits++;if(practice.hits>=3)nextPractice();else renderPractice();
  }
};
events.addEventListener("selection",e=>{
  if(!practice.active)return;
  practice.selections++;practice.totalTime+=e.detail.milliseconds;renderPractice();
});
events.addEventListener("miss",()=>{
  if(practice.active){practice.misses++;renderPractice()}
});
for(const [name,step] of [["calibrated",0],["suggestion",3],["speak",4],["quick",5],["sos",6]]){
  events.addEventListener(name,()=>{if(practice.active&&practice.step===step)nextPractice()});
}
events.addEventListener("type",e=>{
  if(practice.active&&practice.step===2&&e.detail.text.toLocaleLowerCase().includes(tr("hi","नमस्ते")))nextPractice();
});
