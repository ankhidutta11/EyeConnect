/* ============================================================
   I18N, STATIC CONTENT AND NAVIGATION
   ============================================================ */
const sections=[
  ["home","Home","होम"],["dashboard","Dashboard","डैशबोर्ड"],
  ["practice","Practice","अभ्यास"],["how","How it Works","यह कैसे काम करता है"],
  ["privacy","Security & Privacy","सुरक्षा और गोपनीयता"],
  ["vision","Vision","दृष्टि"],["settings","Settings","सेटिंग्स"]
];
$("#mainNav").innerHTML=sections.map(([id,en,hi])=>
  `<a data-dwell href="#${id}">${T(en,hi)}</a>`).join("");
const how=[
  ["Allow the camera","कैमरे की अनुमति दें"],
  ["Calibrate with nine dots","नौ बिंदुओं से कैलिब्रेट करें"],
  ["Look at a key","किसी कुंजी को देखें"],
  ["Hold for your dwell time (2 seconds by default)","तय समय तक नज़र टिकाएँ (डिफ़ॉल्ट 2 सेकंड)"],
  ["Build your sentence","अपना वाक्य बनाएँ"],
  ["Let EyeConnect speak","EyeConnect को बोलने दें"]
];
$("#howSteps").innerHTML=how.map(([en,hi])=>`<div class="step"><p>${T(en,hi)}</p></div>`).join("");
const privacy=[
  ["◉","Video stays here","वीडियो यहीं रहता है",
   "Frames are processed in memory. This app does not record, store, or upload camera video.",
   "फ़्रेम मेमोरी में संसाधित होते हैं। यह ऐप कैमरे का वीडियो रिकॉर्ड, सहेज या अपलोड नहीं करता।"],
  ["◇","Only eyes on screen","स्क्रीन पर केवल आँखें",
   "The model locates face landmarks internally; gaze uses eye and iris measurements. Only cropped eye regions are rendered.",
   "मॉडल अंदरूनी रूप से चेहरे के लैंडमार्क खोजता है; नज़र के लिए आँख और आइरिस माप इस्तेमाल होते हैं। केवल कटी हुई आँखें दिखाई जाती हैं।"],
  ["⌂","Local, not invulnerable","स्थानीय, अभेद्य नहीं",
   "Accounts, phrases and history stay in localStorage, unencrypted. Shared browser profiles can expose them.",
   "खाते, वाक्य और इतिहास localStorage में बिना एन्क्रिप्शन रहते हैं। साझा ब्राउज़र प्रोफ़ाइल से ये दिख सकते हैं।"],
  ["↧","Downloads, not uploads","डाउनलोड, अपलोड नहीं",
   "CDNs and Google model hosting receive ordinary asset requests. There are no ads, analytics, or app telemetry.",
   "CDN और Google मॉडल होस्टिंग को सामान्य डाउनलोड अनुरोध जाते हैं। विज्ञापन, एनालिटिक्स या ऐप टेलीमेट्री नहीं है।"],
  ["×","A real off switch","वास्तविक बंद नियंत्रण",
   "Turning tracking off stops all camera tracks. The camera light should go off unless another app or tab uses it.",
   "ट्रैकिंग बंद करने से कैमरे की सभी ट्रैक रुकती हैं। अन्य ऐप या टैब उपयोग न करे तो कैमरा लाइट बंद होनी चाहिए।"],
  ["↺","Delete whenever you choose","जब चाहें मिटाएँ",
   "Delete messages individually or erase all EyeConnect data. Copying text intentionally transfers it to your clipboard.",
   "एक-एक संदेश या EyeConnect का पूरा डेटा मिटाएँ। कॉपी करने पर आपकी अनुमति से टेक्स्ट क्लिपबोर्ड में जाता है।"]
];
$("#privacyCards").innerHTML=privacy.map(([icon,en,hi,p,q])=>
  `<article class="card"><div class="eyebrow">${icon}</div><h3>${T(en,hi)}</h3><p>${T(p,q)}</p></article>`).join("");
$("#roadmap").innerHTML=[
  ["More languages and stronger personalization","अधिक भाषाएँ और बेहतर निजीकरण"],
  ["Caregiver companion app","देखभालकर्ता सहयोगी ऐप"],
  ["Permission-based smart-home control","अनुमति-आधारित स्मार्ट-होम नियंत्रण"],
  ["Installable, offline-capable edition","इंस्टॉल होने वाला ऑफ़लाइन संस्करण"],
  ["Dedicated eye-tracker integrations","विशेष आई-ट्रैकर एकीकरण"]
].map(([en,hi])=>`<li>${T(en,hi)}</li>`).join("");

function applyLanguage(){
  document.documentElement.lang=state.settings.lang;
  $$("[data-en][data-hi]").forEach(el=>el.textContent=el.dataset[state.settings.lang]);
  $("#message").setAttribute("aria-label",tr("Message","संदेश"));
  $("#menuButton").setAttribute("aria-label",tr("Navigation menu","नेविगेशन मेनू"));
  renderKeyboard();renderSuggestions();renderQuick();renderHistory();
  renderSOSSettings();renderVoices();updateSession();updateStatus();renderPractice();
  $("#historyFilter").innerHTML=[
    ["all","All messages","सभी संदेश"],["normal","Normal","सामान्य"],
    ["quick","Quick phrase","तुरंत वाक्य"],["sos","SOS","SOS"]
  ].map(([v,en,hi])=>`<option value="${v}">${esc(tr(en,hi))}</option>`).join("");
  renderHistory();
}
function go(id){
  $("#"+id)?.scrollIntoView({behavior:motion(),block:"start"});
  $("#mainNav").classList.remove("open");
  $("#menuButton").setAttribute("aria-expanded","false");
}
$("#menuButton").onclick=()=>{
  const on=$("#mainNav").classList.toggle("open");
  $("#menuButton").setAttribute("aria-expanded",String(on));
};
$("#mainNav").addEventListener("click",e=>{
  const a=e.target.closest("a");if(!a)return;
  e.preventDefault();go(a.hash.slice(1));
});
$$('a[href^="#"]').filter(a=>!a.closest("#mainNav")).forEach(a=>{
  a.addEventListener("click",e=>{
    if($(a.hash)){e.preventDefault();go(a.hash.slice(1))}
  });
});
$("#heroDemo").onclick=()=>{go("dashboard");setTimeout(()=>openAuth("signup"),400)};
