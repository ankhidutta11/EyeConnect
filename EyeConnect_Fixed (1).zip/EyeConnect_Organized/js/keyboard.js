/* ============================================================
   TEXT INPUT, KEYBOARD AND PREDICTION
   Hindi uses an InScript-inspired phonetic-independent letter grid.
   It inserts Unicode directly; it is not an OS InScript IME.
   ============================================================ */
const englishRows=["qwertyuiop","asdfghjkl","zxcvbnm"];
const hindiRows=[
  ["ौ","ै","ा","ी","ू","ब","ह","ग","द","ज"],
  ["ो","े","्","ि","ु","प","र","क","त","च"],
  ["ं","म","न","व","ल","स","य","श","ष","।"],
  ["अ","आ","इ","ई","उ","ऊ","ए","ऐ","ओ","औ"],
  ["ऋ","ृ","ख","घ","ङ","छ","झ","ञ","ट","ठ"],
  ["ड","ढ","ण","थ","ध","फ","भ","क्ष","त्र","ज्ञ"],
  ["ँ","ः","़","ॅ","ॉ","ड़","ढ़","श्र","ॐ","ऽ"]
];
const numberRows=[
  ["1","2","3","4","5","6","7","8","9","0"],
  [".",",","?","!",";",":","'","\"", "(",")"],
  ["@","#","₹","$","%","&","*","-","+","="],
  ["/","\\","[","]","{","}","_","०","१","२"],
  ["३","४","५","६","७","८","९","।","…","|"]
];
function keyButton(text,value,wide=false){
  return `<button type="button" data-dwell data-key="${esc(value)}" class="${wide?"wide":""}" aria-label="${esc(text)}">${esc(text)}</button>`;
}
function renderKeyboard(){
  const rows=symbols?numberRows:state.settings.lang==="hi"?hindiRows:englishRows.map(r=>[...r].map(c=>caps?c.toUpperCase():c));
  $("#keyboard").innerHTML=rows.map(row=>`<div class="key-row">${row.map(c=>keyButton(c,c)).join("")}</div>`).join("")+
    `<div class="key-row">
      ${keyButton(tr(caps?"Caps ON":"Caps","कैप्स"),"CAPS",true)}
      ${keyButton(symbols?tr("Letters","अक्षर"):tr("123 / Symbols","123 / चिह्न"),"SYMBOLS",true)}
      ${keyButton(tr("Space","स्पेस"),"SPACE",true)}
      ${keyButton(tr("Backspace","पिछला मिटाएँ"),"BACK",true)}
    </div><div class="key-row">
      ${keyButton("@","@")}${keyButton(".com",".com")}
      ${keyButton(tr("New line","नई पंक्ति"),"ENTER",true)}
      ${keyButton(tr("Clear field","फ़ील्ड मिटाएँ"),"CLEAR",true)}
      ${keyButton(tr("Speak","बोलें"),"SPEAK",true)}
    </div>`;
}
$("#keyboard").addEventListener("pointerdown",e=>{
  if(e.target.closest("button"))e.preventDefault();
});
$("#keyboard").addEventListener("click",e=>{
  const b=e.target.closest("[data-key]");if(!b)return;
  const k=b.dataset.key;
  if(k==="CAPS"){caps=!caps;renderKeyboard();return}
  if(k==="SYMBOLS"){symbols=!symbols;renderKeyboard();return}
  if(k==="SPEAK"){speak(mainTarget.value,"normal");emit("speak");return}
  if(k==="BACK"){editInput("",true);return}
  if(k==="CLEAR"){replaceInput("");return}
  editInput(k==="SPACE"?" ":k==="ENTER"?"\n":k);
});
function isTextField(el){
  return el instanceof HTMLTextAreaElement ||
    (el instanceof HTMLInputElement && !["range","checkbox","radio","button","submit"].includes(el.type));
}
document.addEventListener("focusin",e=>{
  const el=e.target;if(!isTextField(el)||el.readOnly)return;
  activeInput=el;
  if(el.closest("#authDialog")){
    $("#authKeyboard").hidden=false;$("#authKeyboard").append($("#keyboardDock"));
  }else if(el.closest("#editDialog")){
    $("#editKeyboard").append($("#keyboardDock"));
  }else{
    $("#keyboardHome").append($("#keyboardDock"));
  }
  renderSuggestions();
});
function validTarget(){
  if(activeInput?.isConnected&&!activeInput.readOnly&&!activeInput.disabled)return activeInput;
  return mainTarget;
}
function pushUndo(){undo.push(mainTarget.value);if(undo.length>100)undo.shift()}
let lastSentence="";
function recordTyping(){
  state.draft=mainTarget.value;save();
  emit("type",{text:mainTarget.value});
}
function editInput(text,back=false){
  const el=validTarget();if(el===mainTarget)pushUndo();
  const start=el.selectionStart??el.value.length,end=el.selectionEnd??start;
  let from=start;
  if(back&&start===end&&start>0){
    const before=el.value.slice(0,start);
    const segments=globalThis.Intl?.Segmenter
      ? [...new Intl.Segmenter(state.settings.lang,{granularity:"grapheme"}).segment(before)]
      : [...before].map((s,i)=>({segment:s,index:i}));
    from=segments.length?before.length-segments.at(-1).segment.length:0;
  }
  el.setRangeText(back?"":text,from,end,"end");
  el.dispatchEvent(new Event("input",{bubbles:true}));
  if(el===mainTarget){
    recordTyping();
    if(!back&&/\s|[.!?।]/u.test(text))learnText(el.value);
    if(state.settings.autoSpeak&&/[.!?।]\s*$/u.test(el.value)&&el.value!==lastSentence){
      lastSentence=el.value;speak(el.value,"normal");
    }
  }
  renderSuggestions();
}
function replaceInput(value){
  const el=validTarget();if(el===mainTarget)pushUndo();
  el.value=value;el.dispatchEvent(new Event("input",{bubbles:true}));
  if(el===mainTarget)recordTyping();
  renderSuggestions();
}
mainTarget.addEventListener("input",()=>{
  recordTyping();renderSuggestions();
  if(state.settings.autoSpeak&&/[.!?।]\s*$/u.test(mainTarget.value)&&lastSentence!==mainTarget.value){
    lastSentence=mainTarget.value;speak(mainTarget.value,"normal");
  }
});
mainTarget.addEventListener("change",()=>learnText(mainTarget.value));
$("#clearButton").onclick=()=>{activeInput=mainTarget;replaceInput("")};
$("#undoButton").onclick=()=>{
  if(!undo.length)return;
  mainTarget.value=undo.pop();recordTyping();renderSuggestions();
};
$("#copyButton").onclick=async()=>{
  try{
    if(navigator.clipboard?.writeText)await navigator.clipboard.writeText(mainTarget.value);
    else{
      mainTarget.focus();mainTarget.select();
      if(!document.execCommand("copy"))throw Error();
    }
    toast(tr("Copied.","कॉपी हो गया।"));
  }catch{toast(tr("Copy was blocked. Select the message and use your browser’s Copy command.","कॉपी रोक दी गई। संदेश चुनकर ब्राउज़र का कॉपी विकल्प इस्तेमाल करें।"))}
};
const lexicons={
  en:"I:1000 you:900 need:850 help:800 water:780 please:750 hello:650 thank:600 thanks:580 yes:570 no:560 am:550 feel:530 pain:520 family:500 doctor:490 food:480 bathroom:470 comfortable:450 cold:420 hot:400 tired:390 happy:380 love:370 want:360 to:350 call:340 my:330 the:320 is:310 good:300 morning:290 night:280 can:270 come:260 here:250 more:240 medicine:230 breathe:220 sit:210 turn:200 light:190 hungry:180 thirsty:170 fine:160 understand:150 speak:140 today:130 tomorrow:120 home:110 friend:100 hi:90",
  hi:"मुझे:1000 आप:900 पानी:850 चाहिए:800 मदद:780 कृपया:750 नमस्ते:700 धन्यवाद:680 हाँ:650 नहीं:630 मैं:600 हूँ:590 दर्द:580 डॉक्टर:560 परिवार:540 खाना:520 दवा:500 बुलाएँ:480 अच्छा:470 ठीक:460 ठंड:450 गर्मी:440 लग:430 रही:420 है:410 थकान:400 खुश:390 घर:380 चलो:370 शौचालय:360 साँस:350 आराम:340 सुबह:330 शुभ:320 रात:310 कैसे:300 हैं:290 क्या:280 कहाँ:270 कब:260 और:250 थोड़ा:240 अभी:230 बाद:220 सुनिए:210 आइए:200 बैठना:190 मुड़ना:180 रोशनी:170 भूख:160 प्यास:150 प्रेम:140"
};
const base={};
for(const lang of ["en","hi"])base[lang]=Object.fromEntries(lexicons[lang].split(" ").map(x=>{const [w,f]=x.split(":");return[w,Number(f)]}));
const starterBigrams={
  en:{"i":{"need":100,"am":90,"feel":80},"need":{"water":100,"help":90,"food":80},"thank":{"you":100},"good":{"morning":100,"night":80},"call":{"my":100,"doctor":80},"my":{"family":100}},
  hi:{"मुझे":{"पानी":100,"मदद":95,"दवा":80},"पानी":{"चाहिए":100},"मदद":{"चाहिए":100},"मैं":{"ठीक":100},"ठीक":{"हूँ":100},"डॉक्टर":{"बुलाएँ":100},"शुभ":{"रात्रि":100}}
};
const learnedSignatures=new Set();
function wordsOf(text){return text.toLocaleLowerCase().match(/[\p{L}\p{M}]+/gu)||[]}
function learnText(text){
  const lang=state.settings.lang;
  const signature=lang+"|"+text.trim();
  if(!text.trim()||learnedSignatures.has(signature))return;
  learnedSignatures.add(signature);
  const words=wordsOf(text),model=state.learned[lang];
  words.forEach((w,i)=>{
    model.words[w]=(model.words[w]||0)+1;
    if(i){const prev=words[i-1];model.bigrams[prev]||={};model.bigrams[prev][w]=(model.bigrams[prev][w]||0)+1}
  });
  save();
}
function renderSuggestions(){
  const el=validTarget(),lang=state.settings.lang;
  const privateField=el.type==="password"||el.type==="email";
  $("#suggestions").hidden=privateField;
  if(privateField)return;
  const before=el.value.slice(0,el.selectionStart??el.value.length);
  const match=before.match(/[\p{L}\p{M}]+$/u);
  const prefix=(match?.[0]||"").toLocaleLowerCase();
  const words=wordsOf(before),prev=prefix?words.at(-2):words.at(-1);
  const learned=state.learned[lang];
  const candidates=new Set([...Object.keys(base[lang]),...Object.keys(learned.words)]);
  Object.keys(starterBigrams[lang][prev]||{}).forEach(w=>candidates.add(w));
  Object.keys(learned.bigrams[prev]||{}).forEach(w=>candidates.add(w));
  const list=[...candidates].filter(w=>!prefix||w.startsWith(prefix))
    .sort((a,b)=>score(b)-score(a)).slice(0,5);
  function score(w){
    return(base[lang][w]||1)+(learned.words[w]||0)*120+
      (starterBigrams[lang][prev]?.[w]||0)*10+(learned.bigrams[prev]?.[w]||0)*200;
  }
  $("#suggestions").innerHTML=list.map(w=>`<button type="button" data-dwell data-word="${esc(w)}">${esc(w)}</button>`).join("");
}
$("#suggestions").onpointerdown=e=>e.preventDefault();
$("#suggestions").onclick=e=>{
  const b=e.target.closest("[data-word]");if(!b)return;
  const el=validTarget(),pos=el.selectionStart??el.value.length;
  const prefix=el.value.slice(0,pos).match(/[\p{L}\p{M}]+$/u)?.[0]||"";
  el.setSelectionRange(pos-prefix.length,el.selectionEnd??pos);
  editInput(b.dataset.word+" ");
  emit("suggestion");
};
