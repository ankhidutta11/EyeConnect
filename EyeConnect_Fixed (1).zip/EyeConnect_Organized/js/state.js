/* ============================================================
   STATE AND STORAGE
   FRONTEND DEMO ONLY: mock auth is not an authentication system.
   Passwords below are intentionally local demo strings, not secure
   credentials. Real authentication needs a secure backend.
   No video, landmark frames, or calibration samples are persisted.
   ============================================================ */
const $ = (s, root=document) => root.querySelector(s);
const $$ = (s, root=document) => [...root.querySelectorAll(s)];
const clamp = (n,a,b) => Math.max(a,Math.min(b,n));
const uid = () => globalThis.crypto?.randomUUID?.() ||
  Date.now().toString(36)+Math.random().toString(36).slice(2);
const esc = value => String(value).replace(/[&<>"']/g,c=>({
  "&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"
}[c]));
const KEY = "eyeconnect.demo.v1";
const defaults = {
  lang:"en",dwell:2,gain:1,smooth:.72,blink:true,arrows:true,
  theme:"dark",contrast:false,keySize:"medium",font:1,
  rate:1,pitch:1,volume:1,autoSpeak:false,voice:"",
  contactName:"",contactNumber:"",camera:"",sosIndex:0,
  sos:{
    en:["Emergency! I need help immediately.","I cannot breathe.","I am in pain.","Call a doctor.","Call my family."],
    hi:["आपातकाल! मुझे तुरंत मदद चाहिए।","मुझे साँस नहीं आ रही है।","मुझे दर्द हो रहा है।","डॉक्टर को बुलाएँ।","मेरे परिवार को बुलाएँ।"]
  }
};
let disk={};
try{disk=JSON.parse(localStorage.getItem(KEY)||"{}")}catch{}
const state={
  settings:{...structuredClone(defaults),...(disk.settings||{})},
  accounts:Array.isArray(disk.accounts)?disk.accounts:[],
  session:disk.session||null,
  phrases:Array.isArray(disk.phrases)?disk.phrases:[],
  history:Array.isArray(disk.history)?disk.history:[],
  learned:disk.learned||{en:{words:{},bigrams:{}},hi:{words:{},bigrams:{}}},
  draft:typeof disk.draft==="string"?disk.draft:""
};
if(!state.settings.sos?.en || !state.settings.sos?.hi)
  state.settings.sos=structuredClone(defaults.sos);
state.settings.lang=state.settings.lang==="hi"?"hi":"en";
for(const lang of ["en","hi"]){
  state.learned[lang] ||= {words:{},bigrams:{}};
}
let storageWarning=false;
function save(){
  try{localStorage.setItem(KEY,JSON.stringify(state))}
  catch{
    if(!storageWarning){storageWarning=true;toast(tr("Storage is unavailable or full. Changes will last only for this tab.","स्टोरेज उपलब्ध नहीं या भरा हुआ है। बदलाव केवल इस टैब तक रहेंगे।"))}
  }
}
const tr=(en,hi)=>state.settings.lang==="hi"?hi:en;
const T=(en,hi)=>`<span data-en="${esc(en)}" data-hi="${esc(hi)}">${esc(tr(en,hi))}</span>`;
let toastTimer;
function toast(text){
  $("#toast").textContent=text;
  clearTimeout(toastTimer);
  toastTimer=setTimeout(()=>$("#toast").textContent="",6500);
}
let mainTarget=$("#message"),activeInput=$("#message"),undo=[],caps=false,symbols=false;
$("#message").value=state.draft;
const events=new EventTarget();
const emit=(type,detail={})=>events.dispatchEvent(new CustomEvent(type,{detail}));
const reduced=matchMedia("(prefers-reduced-motion: reduce)");
const motion=()=>reduced.matches?"auto":"smooth";
