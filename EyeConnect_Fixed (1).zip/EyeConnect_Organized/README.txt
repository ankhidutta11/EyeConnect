EyeConnect organized project

Run using a local server (localhost/HTTPS recommended for camera permissions).

Files: index.html, css/style.css, js/*.js. External Three.js/GSAP/MediaPipe dependencies load from CDNs.
